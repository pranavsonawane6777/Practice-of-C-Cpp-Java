// Below statements are used to import the package
import Marvellous.Demo;
import Marvellous.Hello;

class PPA
{
    public static void main(String arg[])
    {
        Demo dobj = new Demo();
        Hello hobj = new Hello();

        dobj.fun();
        hobj.gun();
    }
}

// javac PPA.java
// java PPA