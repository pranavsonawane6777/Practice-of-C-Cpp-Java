// Below statement is used to create the package named as Marvellous
package Marvellous;

public class Demo
{
    public void fun()
    {
        System.out.println("Inside fun of Demo");
    }
}

// javac Demo.java  -d .
// -d       Directory
// .        Current Directory