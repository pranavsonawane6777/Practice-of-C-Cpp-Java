// Below statement is used to create the package named as Marvellous
package Marvellous;

public class Hello
{
    public void gun()
    {
        System.out.println("Inside gun of Hello");
    }
}

// javac Hello.java -d .
// -d       Directory
// .        Current Directory